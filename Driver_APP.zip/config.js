export const API = "http://62.72.3.95:8090/mobileapi/user";
export const LeaveApi = "http://62.72.3.95:8090/mobileapi/leave";
export const ComplainApi = "http://62.72.3.95:8090/mobileapi/complain";
export const RidesApi = "http://62.72.3.95:8090/mobileapi/ride";
export const dependentApi = "http://62.72.3.95:8090/mobileapi/dependent";
export const mobileApi = "http://62.72.3.95:8090/mobileapi";
