import { StyleSheet, Text, View } from "react-native";
import React from "react";

const TermsAndConditions = () => {
  return (
    <View>
      <Text>Terms&Conditions</Text>
    </View>
  );
};

export default TermsAndConditions;

const styles = StyleSheet.create({});
