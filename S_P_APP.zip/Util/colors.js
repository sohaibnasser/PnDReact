export const colors = {
  blue: "#3497fd",
  black: "#000",
  white: "#fff",
  green: "#55cd85",
  grey: "",
};
